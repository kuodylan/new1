# ex26_2.py
import pandas as pd
years = range(2021, 2026)
visiters = [400,420,450,480,500]
s = pd.Series(visiters, index = years)
print(s)







