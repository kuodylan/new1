# ex4_4.py
num = input("請輸入3位數數字：")
num = int(int(num) / 10)
numstr = str(num) + '0'
print(f"執行結果: {numstr}")



