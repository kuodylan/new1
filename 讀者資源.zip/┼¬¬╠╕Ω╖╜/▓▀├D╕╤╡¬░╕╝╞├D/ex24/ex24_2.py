# ex24_2.py
import numpy as np

x = [350, 420, 388, 322, 460, 377, 390]
print(f'平均來客數 = {np.mean(x):6.2f}')
print(f"母體變異數 = {np.var(x):6.2f}")
print(f"母體標準差 = {np.std(x):6.2f}")



