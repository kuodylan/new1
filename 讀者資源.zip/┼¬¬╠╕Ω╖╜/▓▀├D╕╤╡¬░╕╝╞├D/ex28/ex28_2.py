# ch28_2.py
import webbrowser

address = input("請輸入地址 : ")
webbrowser.open('http://www.google.com.tw/maps/place/' + address)


