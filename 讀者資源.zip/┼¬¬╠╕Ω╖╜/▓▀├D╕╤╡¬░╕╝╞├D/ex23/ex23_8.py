# ex23_8.py
import numpy as np

x = np.arange(20)
print(f"原陣列 x = {x}")
y = np.reshape(x,(4,5))
print("新陣列 y =")
print(y)





