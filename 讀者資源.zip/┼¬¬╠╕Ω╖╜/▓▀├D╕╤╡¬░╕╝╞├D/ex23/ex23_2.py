# ex23_2.py
import numpy as np

x = np.arange(1,51).reshape(5,10)
print(x)











