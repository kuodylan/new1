# ex23_4.py
import numpy as np

x1 = np.array([1,3,5,7,9])
x2 = np.array([2,4,5,7,9])
x = np.concatenate((x1,x2))
print(x)











