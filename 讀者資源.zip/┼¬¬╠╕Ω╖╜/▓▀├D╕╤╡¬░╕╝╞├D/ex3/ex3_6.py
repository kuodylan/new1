# ex3_6.py
code1 = '洪'
print('洪')
print(hex(ord(code1)))     # 輸出字元'洪'的Unicode(16進位)碼值
code2 = '錦'
print('錦')
print(hex(ord(code2)))     # 輸出字元'錦'的Unicode(16進位)碼值
code3 = '魁'
print('魁')
print(hex(ord(code3)))     # 輸出字元'魁'的Unicode(16進位)碼值

