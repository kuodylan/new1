# ex6_8.py
site = input("請輸入網址 : ")
if site.startswith("http://") or site.startswith("https://"):
    print("網址格式正確")
else:
    print("網址格式錯誤")


               

















