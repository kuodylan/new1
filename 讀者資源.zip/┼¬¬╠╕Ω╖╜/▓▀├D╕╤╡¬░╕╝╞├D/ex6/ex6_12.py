# ex6_12.py
abc = 'abcdefghijklmnopqrstuvwxyz'
front5 = abc[:5]
end21 = abc[5:]
subText = end21 + front5
print("abc     = ", abc)
print("subText = ", subText)


