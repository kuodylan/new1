# ex6_2.py
cars = ['Toyota', 'Nissan', 'Honda']
print("舊汽車銷售品牌", cars)
cars[1] = 'Ford'           # 更改第二筆元素內容
print("新汽車銷售品牌", cars)


    
